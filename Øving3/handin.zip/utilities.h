

int randomWithLimits(int high, int low);
void playTargetPractice();