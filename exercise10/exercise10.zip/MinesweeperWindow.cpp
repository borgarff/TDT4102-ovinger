#include "MinesweeperWindow.h"
#include "Tile.h"
#include <cstdlib>

MinesweeperWindow::MinesweeperWindow(Point xy, int width, int height, int mines, const string& title) :
	Graph_lib::Window{xy, width * cellSize, 50 + height*cellSize, title}, width{width}, height{height}, mines{mines} {
	//Initialiser medlemsvariabler, bruker konstruktoren til Windowsklassen 
	openTiles = 0;
	// Legg til alle tiles i vinduet
	for (int i = 0; i < height; ++i) {
		for (int j = 0; j < width; ++j) {
			tiles.push_back(new Tile{ Point{j * cellSize, i * cellSize}, cellSize, cb_click });
			attach(tiles.back());
		}
	}

	//Legg til miner paa tilfeldige posisjoner
	
	for (int k = 0; k < mines; k++) {
		int rnd = -1;
		do {
			rnd = rand() % tiles.size();
			if (!tiles[rnd].getIsMine()) {
				tiles[rnd].setIsMine();
			}
		}while (!tiles[rnd].getIsMine());
	}
	
	

	// Fjern window reskalering
	resizable(nullptr);
	size_range(x_max(), y_max(), x_max(), y_max());
}


vector<Point> MinesweeperWindow::adjacentPoints(Point xy) const {
	vector<Point> points;
	for (int di = -1; di <= 1; ++di) {
		for (int dj = -1; dj <= 1; ++dj) {
			if (di == 0 && dj == 0) {
				continue;
			}

			Point neighbour{ xy.x + di * cellSize,xy.y + dj * cellSize };
			if (inRange(neighbour)) {
				points.push_back(neighbour);
			}
		}
	}
	return points;
}

void MinesweeperWindow::openTile(Point xy) {
	string feedback;
	bool finish = false;

	if (at(xy).getState() == Cell::closed) {
		at(xy).open();
		if (!at(xy).getIsMine()) {
			if (countMines(adjacentPoints(xy))) {
				at(xy).setAdjMines(countMines(adjacentPoints(xy)));
			}
			else {
				for (auto it: adjacentPoints(xy)) {
					openTile(Point{it.x, it.y});
				}
			}

		}
		else {
			feedback = "Du tapte";
			cout << feedback << endl;
			finish = true;
		}
		openTiles++;
		if (checkWin()) {
			feedback = "Du har vunnet!";
			cout << feedback << endl;
			finish = true;
		}

		if (finish) {
			static Text text{Point{0, 330}, feedback};
			text.set_font_size(45);
			text.set_color(Color::black);
			attach(text);
		}

	}
}

void MinesweeperWindow::flagTile(Point xy) {
	if (at(xy).getState() != Cell::open) {
		at(xy).flag();
	}
	
}

//Kaller openTile ved venstreklikk og flagTile ved hoyreklikk/trykke med to fingre paa mac
void MinesweeperWindow::click()
{
	Point xy{Fl::event_x(), Fl::event_y()};

	MouseButton mb = static_cast<MouseButton>(Fl::event_button());

	if (!inRange(xy)) {
		return;
	}

	switch (mb) {
	case MouseButton::left:
		openTile(xy);
		break;
	case MouseButton::right:
		flagTile(xy);
		break;
	}

	flush();
}

int MinesweeperWindow::countMines(vector<Point> points) {
	int nrMines = 0;
	
	for (auto it: points) {
		if (at(Point{it.x, it.y}).getIsMine()) {
			nrMines++;
		}
	}
	return nrMines;
}

bool MinesweeperWindow::checkWin() {
	if ((tiles.size() - openTiles) == mines) return true;
	return false;
}