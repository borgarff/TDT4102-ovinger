#include "std_lib_facilities.h"

void readFromFile();
void writeToFile();