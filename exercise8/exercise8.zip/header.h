
#include <ostream>
#include "Graph_lib/Window.h"
#include "Graph_lib/Graph.h"
#include "Graph_lib/Point.h"
#include "Graph_lib/GUI.h"